#! /bin/bash

set -ex
